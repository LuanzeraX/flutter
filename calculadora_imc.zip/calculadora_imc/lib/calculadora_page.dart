import 'dart:html';

import 'package:flutter/material.dart';
import 'constants.dart';
import 'package:flutter/material.dart';
import 'components/custom_cart.dart';
import 'components/icon_content.dart';

class calculadoraPage extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Calculadora IMC"),
          centerTitle: true,
        ),
        body: Column(
          children: [
            Expanded(
              child: Row(
                children: [
                  Expanded(
                    child: CustomCard(
                      child: IconContent(icon: Icons.male, text:"Masculino",),
                    ),
                  ),
                  Expanded(
                    child: CustomCard(
                      child: IconContent(icon: Icons.female, text: 'Feminino',),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: CustomCard(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                  Text('Altura', style: kLabelTextStyle,),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      textBaseline: TextBaseline.alphabetic,
                    children: [
                      Text('1.84', style: kNumberTextStyle,),
                      Text('50')
                    ],
                  ),
                  Slider(value: 0, onChanged: (double value) {})
                ],),
              ),
            ),
            Expanded(
              child: CustomCard(
                child: Placeholder(),
              ),
            ),
          ],
        ));
  }
}


