
import 'package:calculadora_imc/calculadora_page.dart';
import 'package:flutter/material.dart';
import 'constants.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
 @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculadora IMC',
      home: calculadoraPage(),
      theme: ThemeData.dark().copyWith(
      primaryColor: kBackgroundColor,
      scaffoldBackgroundColor: kBackgroundColor,
      appBarTheme: AppBarTheme().copyWith(
        backgroundColor: kBackgroundColor,
      ),
      ),
    );
  }
         
         
         
         }
